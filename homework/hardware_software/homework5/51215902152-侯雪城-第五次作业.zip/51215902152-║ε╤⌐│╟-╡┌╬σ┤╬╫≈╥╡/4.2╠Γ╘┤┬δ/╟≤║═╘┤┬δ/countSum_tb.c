#include<stdio.h>
#include"countSum.h"

int main(void)
{
	countSum(10000);
	return 0;
}




