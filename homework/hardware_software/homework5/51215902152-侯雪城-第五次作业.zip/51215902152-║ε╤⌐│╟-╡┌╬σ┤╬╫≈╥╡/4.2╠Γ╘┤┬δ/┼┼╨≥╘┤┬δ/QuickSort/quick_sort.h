#include<ap_cint.h>

uint8 partition(uint8 *arr,uint8 low,uint8 high);
void quickSort(uint8 *arr,uint8 low,uint8 high);
