#include<ap_cint.h>

uint64 countSum(uint64);
