#include<stdio.h>
#include"bubble_sort.h"
int main(void){
	uint8 arr[]={3,4,1,8,0,5,14,10,12,20,23,24,2,17,6,18,9,19};
	bubble_sort(arr,18);
	return 0;
}
